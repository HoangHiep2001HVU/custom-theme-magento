# Version 1.0.3 - 07/23/2021
- Fix issue not display brands when open brands page
- Add custom css class to body tag when view brand item detail page. Fix issue for theme SM
- Add check ajax request to response brand products.

# Version 1.0.4 - 02/23/2022
- Upgrade database schema, add foreign keys for brand_id, product_id in table ves_brand_product
